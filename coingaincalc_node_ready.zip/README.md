# CoinGainCalc - Render + GitHub ready Node.js project

This repository is prepared to deploy the CoinGainCalc app on Render (or any Node.js host).
It serves static frontend from `/public` and runs an Express server (`server.js`).

## What's included
- `server.js` - Express server configured for Render (uses `process.env.PORT`)
- `public/` - frontend files (index.html, style.css, script.js, assets/)
- `analytics/ga4.js` - small helper to include GA4 (Measurement ID embedded)
- `package.json` - includes start script (`npm start`)
- `.gitignore`

## How to deploy to Render (quick)
1. Push this repository to GitHub.
2. Go to https://render.com → "New" → "Web Service".
3. Connect your GitHub repository and pick the `main` branch.
4. Set **Build Command** to (leave empty if no build needed):
   ```
   npm install
   ```
   (If you add a build step later, use: `npm install && npm run build`)
5. Set **Start Command** to:
   ```
   npm start
   ```
6. Add any environment variables in Render dashboard if needed (.env values).
7. Create the service — Render will deploy and provide a URL like `https://your-app.onrender.com`.

## Custom domain (coingaincalc.com)
1. In Render service settings, add your custom domain `coingaincalc.com`.
2. Render will provide DNS records: typically a CNAME or A record. In your domain registrar's DNS panel, add those records.
3. Allow DNS to propagate (may take minutes to hours). Render provisions SSL automatically.

## Google Analytics (GA4)
GA4 Measurement ID is already included in `analytics/ga4.js` and `public/index.html`.
Measurement ID: **G-R42DCE7600**

## Local testing
```bash
npm install
npm start
# then open http://localhost:3000
```

---
Ready to push to GitHub and connect to Render.
