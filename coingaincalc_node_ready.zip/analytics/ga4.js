// Google Analytics 4 basic loader (GA4 Measurement ID embedded)
(function(){
  // Replace with your GA4 ID
  var GA4_ID = 'G-R42DCE7600';

  // gtag loader
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', GA4_ID);

  var s = document.createElement('script');
  s.async = true;
  s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA4_ID;
  var first = document.getElementsByTagName('script')[0];
  first.parentNode.insertBefore(s, first);
})();
